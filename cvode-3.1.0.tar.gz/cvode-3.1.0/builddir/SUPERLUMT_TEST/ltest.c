#include "slu_mt_ddefs.h"
int main(){
SuperMatrix A;
NCformat *Astore;
return(0);
}
