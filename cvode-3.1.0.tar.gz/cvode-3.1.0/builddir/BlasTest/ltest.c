#define SUNDIALS_F77_FUNC(name,NAME) name ## _
#define dcopy_f77 SUNDIALS_F77_FUNC(dcopy, DCOPY)
extern void dcopy_f77(int *n, const double *x, const int *inc_x, double *y, const int *inc_y);
int main(){
int n=1;
double x, y;
dcopy_f77(&n, &x, &n, &y, &n);
return(0);
}
