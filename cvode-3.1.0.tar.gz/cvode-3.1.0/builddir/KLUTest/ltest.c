#include "klu.h"
int main(){
klu_common Common;
klu_defaults (&Common);
return(0);
}
